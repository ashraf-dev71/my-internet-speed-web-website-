import React, { useState, useRef, useEffect } from 'react';
import { Menu, X, User, Shield, FileCode, Check, Copy, ExternalLink } from 'lucide-react';
import { ActiveTab } from '../types';

interface TopCornerMenuProps {
  onNavigateToTab: (tab: ActiveTab) => void;
}

export const TopCornerMenu: React.FC<TopCornerMenuProps> = ({ onNavigateToTab }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const dropdownRef = useRef<HTMLDivElement | null>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <>
      <div className="relative" ref={dropdownRef}>
        <button
          id="btn-top-menu"
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Toggle Navigation Menu"
          className="p-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-cyan-400 border border-slate-800 transition-all duration-300"
        >
          {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

        {/* Dropdown Menu */}
        {isOpen && (
          <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl z-50 py-2 overflow-hidden animate-fadeIn">
            <div className="px-4 py-2 border-b border-slate-800/80 text-[11px] font-mono text-slate-400 uppercase tracking-wider">
              Network Utility Menu
            </div>

            <button
              id="menu-item-creator"
              onClick={() => {
                onNavigateToTab('creator');
                setIsOpen(false);
              }}
              className="w-full px-4 py-2.5 text-left text-xs font-medium text-slate-200 hover:text-cyan-300 hover:bg-slate-800/80 flex items-center gap-2.5 transition-colors"
            >
              <User className="w-4 h-4 text-cyan-400" />
              <span>Creator Information</span>
            </button>

            <button
              id="menu-item-privacy"
              onClick={() => {
                setShowPrivacyModal(true);
                setIsOpen(false);
              }}
              className="w-full px-4 py-2.5 text-left text-xs font-medium text-slate-200 hover:text-cyan-300 hover:bg-slate-800/80 flex items-center gap-2.5 transition-colors"
            >
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>Disclaimer & Privacy</span>
            </button>

            <button
              id="menu-item-export"
              onClick={() => {
                setShowExportModal(true);
                setIsOpen(false);
              }}
              className="w-full px-4 py-2.5 text-left text-xs font-medium text-slate-200 hover:text-cyan-300 hover:bg-slate-800/80 flex items-center gap-2.5 transition-colors border-t border-slate-800/60 mt-1"
            >
              <FileCode className="w-4 h-4 text-indigo-400" />
              <span>GitHub Pages Deployment Guide</span>
            </button>
          </div>
        )}
      </div>

      {/* Disclaimer & Privacy Modal */}
      {showPrivacyModal && (
        <div className="fixed inset-0 z-[2000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl flex flex-col gap-4 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 text-emerald-400">
                <Shield className="w-5 h-5" />
                <h3 className="font-bold text-slate-100 text-base">Disclaimer & Privacy Policy</h3>
              </div>
              <button
                onClick={() => setShowPrivacyModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-300 leading-relaxed max-h-[60vh] overflow-y-auto pr-1">
              <div>
                <h5 className="font-semibold text-slate-100 mb-1">1. Pure Client-Side Architecture</h5>
                <p>
                  This Single Page Application operates 100% in your browser. No speed test metrics, downloaded bytes, or network diagnostics are recorded or saved to any proprietary backend or third-party database.
                </p>
              </div>

              <div>
                <h5 className="font-semibold text-slate-100 mb-1">2. Local Storage Persistence</h5>
                <p>
                  Your speed test history is stored strictly in your browser's private <code className="text-cyan-400 font-mono">localStorage</code>. You can export or clear this history anytime.
                </p>
              </div>

              <div>
                <h5 className="font-semibold text-slate-100 mb-1">3. Open-Source & Public APIs</h5>
                <p>
                  To provide IP detection and geolocation mapping, this application communicates directly with public open-source services (such as ipwho.is, ipapi, and OpenStreetMap via Leaflet.js). No API keys or authentication tokens are required.
                </p>
              </div>

              <div>
                <h5 className="font-semibold text-slate-100 mb-1">4. Speed Measurement Accuracy</h5>
                <p>
                  Speed measurements are computed via client-side multi-stream chunk timing. Results may vary slightly depending on your Wi-Fi signal, active device apps, and browser overhead.
                </p>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setShowPrivacyModal(false)}
                className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-colors"
              >
                Understood & Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* GitHub Pages Deployment Guide Modal */}
      {showExportModal && (
        <div className="fixed inset-0 z-[2000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl flex flex-col gap-4 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 text-indigo-400">
                <FileCode className="w-5 h-5" />
                <h3 className="font-bold text-slate-100 text-base">Hosting on GitHub Pages</h3>
              </div>
              <button
                onClick={() => setShowExportModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
              <p>
                This application requires <span className="font-semibold text-cyan-300">zero backend servers</span> and is 100% static client-side ready for GitHub Pages!
              </p>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2 font-mono text-[11px]">
                <div className="text-slate-400 font-sans font-semibold">Option A: Automated GitHub Deployment</div>
                <div className="text-cyan-400"># 1. Build and push to your GitHub repo</div>
                <div className="text-slate-300">git push origin main</div>
                <div className="text-emerald-400 text-[10px]"># GitHub Actions (.github/workflows/deploy.yml) will auto-deploy!</div>
                <div className="text-cyan-400 mt-2"># Or deploy in 1 command with gh-pages:</div>
                <div className="text-slate-200">npm run deploy</div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-cyan-500/20 space-y-2">
                <div className="text-cyan-300 font-sans font-semibold">Option B: Pure Zero-Build Vanilla HTML</div>
                <p className="text-[11px] text-slate-300">
                  If you want to host on GitHub Pages without using Node or npm build tools, we also built a complete self-contained single-file <code className="text-cyan-400">standalone.html</code>.
                </p>
                <div className="flex gap-2 pt-1">
                  <a
                    href="./standalone.html"
                    download="index.html"
                    className="flex-1 text-center py-2 px-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-colors"
                  >
                    Download index.html for GitHub
                  </a>
                  <a
                    href="./standalone.html"
                    target="_blank"
                    rel="noreferrer"
                    className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs border border-slate-700 transition-colors"
                  >
                    Preview
                  </a>
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setShowExportModal(false)}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition-colors border border-slate-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
